<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/png" href="HSN/HSN_LOGO.png">
    <title>Hotel Satya Nugraha</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        body{
            font-family:Arial;
            background-color:#F0FFF0;
            color:#000000;
        }
        .jumbotron{          
            background-image:url(HSN/kolam.jpg);
            color:white;
            text-align:center;
            background-color:#F8F8FF;
            background-attachment: fixed;
            background-repeat: no-repeat;
            background-size: 100% 75%;
            height:500px;
            
            
        }
        .bd-example{
            width:600px;
            height:500px;
            
        }
        #box:hover{
            background:#FFE4C4;
        }

        #box1:hover{
            background:#FFE4C4;
        }

        #box2:hover{
            background:#FFE4C4;
        }

        #box3:hover{
            background:#FFE4C4;
        }

        #box4:hover{
            background:#FFE4C4;
        }

        #box5:hover{
            background:#FFE4C4;
        }

        #box6:hover{
            background:#FFE4C4;
        }

        #box7:hover{
            background:#FFE4C4;
        }

        #box8:hover{
            background:#FFE4C4;
        }

        #box9:hover{
            background:#FFE4C4;
        }

        #box10:hover{
            background:#FFE4C4;
        }

        #box11:hover{
            background:#FFE4C4;
        }

        #box12:hover{
            background:#FFE4C4;
        }

        #box13:hover{
            background:#FFE4C4;
        }

        #box14:hover{
            background:#FFE4C4;
        }

        #box15:hover{
            background:#FFE4C4;
        }

        #box16:hover{
            background:#FFE4C4;
        }

        #box17:hover{
            background:#FFE4C4;
        }
        
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark" >
        <img src="HSN/HSN_LOGO.png" alt="">
        <a class="navbar-brand " href="#"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse " id="navbarTogglerDemo02">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0 " style="text-align:right;">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Home <span class="sr-only"></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#profilhotel">About us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reservasi.php">Reservation</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kontakhotel.php">Contact us</a>
                </li>
            </ul>
        </div>
        
    </nav>
    <div class="jumbotron jumbotron-fluid"><br><br><br>
        <div class="container">
            <marquee behavior="alternate" direction="right">
                <h1 class="">Welcome to Website of Satya Nugraha Hotel Yogyakarta</h1>
                <center><p class="lead">Relax Peaceful Business Gorgeous</p></center>
            </marquee>
        </div>
    </div>
    <br><br><br><br><br>
    <center>
        <div class="container">
            <h3 id="profilhotel">About Us</h3><br>
            <div class="row justify-content-md-center">
                <p >We are located in the east of the city, it is 10 minutes drive from the air port 3 kilometres from railway station, 1000 metres from super market and 15 minutes drive from Malioboro. Welcome to our hotel, we’re waiting for you</p>

            </div>
        </div>
        <br>
    
        <div class="bd-example" >
            <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#carouselExampleCaptions" data-slide-to="0"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="3"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="4"></li>
                    <li data-target="#carouselExampleCaptions" data-slide-to="5"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="HSN/22082019110351anggrek1.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5></h5>
                            
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="HSN/asri.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5></h5>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="HSN/kolam.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5></h5>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="HSN/pasarkaget.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5></h5>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="HSN/ruangmeeting.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5></h5>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img src="HSN/tari.jpg" class="d-block w-100" alt="...">
                        <div class="carousel-caption d-none d-md-block">
                            <h5></h5>
                        </div>
                    </div>
                </div>
                <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </center>
    <div class="container">
        <center><h4>Facilities</h4>
            <hr>
            <p>We have clean and comfortable rooms. In addition we also have a lot of supporting facilities. Among other things:</p>
        </center>
        <div class="row justify-content-md-center">
            
            <div id="box" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/air-conditioner.png" width="50px" alt="">
                    <p>40 Equiped Aircond Rooms</p>
                </center>
            </div>
            <div id="box1" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/meeting-room.png" width="50px" alt="">
                    <p>2 Meeting Rooms</p>
                </center>
            </div>
            <div id="box2" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/reception.png" width="50px" alt="">
                    <p>24-hours Room Service</p>
                </center>
            </div>
            <div id="box3" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/swimming-silhouette.png" width="50px" alt="">
                    <p>The Swimming Pool</p>
                </center>
            </div>
            <div id="box4" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/hotspot.png" width="50px" alt="">
                    <p>Hotspot Area</p>
                </center>
            </div>
        </div><br>
        <div class="row justify-content-md-center">
            <div id="box5" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/organic-food.png" width="50px" alt="">
                    <p>Tropical Fresh Garden</p>
                </center>
            </div>
            <div id="box6" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/billiard.png" width="50px" alt="">
                    <p>Billiard</p>
                </center>
            </div>
            <div id="box7" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/cityscape.png" width="50px" alt="">
                    <p>City Tour</p>
                </center>
            </div>
            <div id="box8" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/parking-area.png" width="50px" alt="">
                    <p>Spacious Parking Area</p>
                </center>
            </div>
            <div id="box9" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/smartphone.png" width="50px" alt="">
                    <p>Doctor On Call</p>
                </center>
            </div>
        </div><br>
        <div class="row justify-content-md-center">
            <div id="box10" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/credit-card.png" width="50px" alt="">
                    <p>Major Credit Cards Accepted</p>
                </center>
            </div>
            <div id="box11" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/ticket.png" width="50px" alt="">
                    <p>Ticketing</p>
                </center>
            </div>
            <div id="box12" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/laundry.png" width="50px" alt="">
                    <p>Laundry Service</p>
                </center>
            </div>
            <div id="box13" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/automobile.png" width="50px" alt="">
                    <p>Car Rental</p>
                </center>
            </div>
            <div id="box14" class="col-6 col-sm-2">
                &nbsp;
                <center>
                    <img src="HSN/taxi.png" width="50px" alt="">
                    <p>Taxi Call Service</p>
                </center>
            </div>
        </div>
        <center><p>We believe that being able to satisfy you while in Yogyakarta.</p></center>
        

        
        </div>
    </div>
    <hr>
    <!--<center>&copy; Yuri Mahendra</center>-->
    
   
    
        
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>