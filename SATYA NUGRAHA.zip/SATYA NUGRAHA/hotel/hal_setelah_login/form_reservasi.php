<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/png" href="../HSN/HSN_LOGO.png">
    <title>Reservation</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">

    <style>
        body{
            font-family:Arial;
            background-color:#F8F8FF;
            color:#000000;
        }
        
        .bd-example{
            width:400px;
            height:300px;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ">
        <img src="../HSN/HSN_LOGO.png" alt="">
        <a class="navbar-brand " href="#"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse " id="navbarTogglerDemo02">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0 " style="text-align:right;">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Home <span class="sr-only"></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">About us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reservasi.php">Reservation</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kontakhotel.php">Contact us</a>
                </li>
            </ul>
        </div>
        <div class="dropdown">
        <?php 
            session_start();  
            if($_SESSION['nama_user']=='')
            {
                header("location:../login.php");
            }      
        ?>
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo $_SESSION['nama_user']?>
        </button>
        
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="logout.php">Logout</a>
        </div>
        </div>
    </nav>
    <br>

    <div class="container">
        <div class="row justify-content-md-center">
            <div class="col-12 col-md-8">
            <h3 class="text-center">Form Reservation</h3>
                <hr>
                
                <form action="proses_reservasi.php" method="post" name="form">
                
                    <div class="form-group row">
                        <label class="col-sm-4  col-form-label">Name Guest</label>
                        <div class="col">
                            <input type="text" name="namatamu[]" class="form-control" placeholder="First name" required="required">
                        </div>
                        <div class="col">
                            <input type="text" name="namatamu[]" class="form-control" placeholder="Last name" required="required">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label  class="col-sm-4 col-form-label">No. KTP/Pasport/SIM</label>
                        <div class="col">
                            <input type="number" name="noidentitas" class="form-control"  placeholder="No. Identitas" required="required">
                        </div>
                    </div>
                     <div class="form-group row">
                        <label  class="col-sm-4 col-form-label">Phone</label>
                        <div class="col">
                            <input type="number" name="phone" class="form-control"  placeholder="Phone" required="required">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label  class="col-sm-4 col-form-label">Email</label>
                        <div class="col">
                            <input type="email" name="email" class="form-control" placeholder="Email" required="required">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label">Check In</label>
                        <div class="col" >
                            <div class="input-group date">
                                <input placeholder="date" name="checkin" type="" class="form-control datepicker" name="checkin" required="required">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label">Check Out</label>
                        <div class="col" >
                            <div class="input-group date">
                                <input placeholder="date" name="checkout" type="" class="form-control datepicker" name="checkout" required="required">
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label">Choose Room</label>
                        <div class="col" >
                            <select name="pilihkamar" class="custom-select" required="required">
                                <option value="ANGGREK AC I Rp 340.000">ANGGREK AC I Rp 340.000,-</option>
                                <option value="ANGGREK AC II Rp 280.000">ANGGREK AC II Rp 280.000,-</option>
                                <option value="MELATI AC I Rp 250.000">MELATI AC II Rp 200.000,-</option>
                                <option value="MELATI AC II Rp 200.000">MELATI AC II Rp 200.000,-</option>
                                <option value="FLAMBOYAN AC Rp 130.000">FLAMBOYAN AC Rp 130.000,-</option>
                                <option value="FLAMBOYAN AC Rp 190.000">FLAMBOYAN AC Rp 190.000,-</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label">Number Of Rooms</label>
                        <div class="col" >
                            <select name="jumlahkamar" class="custom-select" required="required">
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>
                        </div>
                    </div>
                    <!--<div class="form-group row">
                        <label class="col-sm-4 col-form-label">Layanan tambahan</label>
                        <div class="col" >
                            <select name="layanantambahan" class="custom-select" required="required" >
                                <option></option>
                                <option value="Extra Bed Anggrek AC I/II: Rp 118.000">Extra Bed Anggrek AC I/II: Rp 118.000</option>
                                <option value="Extra Bed Melati AC I/II: Rp 98.000">Extra Bed Melati AC I/II: Rp 98.000</option>
                                <option value="Extra Bed Flamboyan AC (Limited Service): Rp 50.000">Extra Bed Flamboyan AC (Limited Service): Rp 50.000</option>
                                <option value="Extra Bed Flamboyan AC (full service): Rp 80.000">Extra Bed Flamboyan AC (full service): Rp 80.000</option>
                                <option value="Breakfast">Breakfast</option>
                            </select>
                        </div>
                    </div>-->
                    
                    <div class="form-group row">
                        <label class="col-sm-4 col-form-label">Other Service</label>
                        <div class="col" >
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" name="otherservice[]" class="custom-control-input" id="0" value="Extra Bed Anggrek AC I/II: Rp 118.000">
                                <label class="custom-control-label" for="0">Extra Bed Anggrek AC I/II: Rp 118.000,-</label>
                            </div>
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" name="otherservice[]" class="custom-control-input" id="1" value="Extra Bed Melati AC I/II: Rp 98.000">
                                <label class="custom-control-label" for="1">Extra Bed Melati AC I/II: Rp 98.000,-</label>
                            </div>
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" name="otherservice[]" class="custom-control-input" id="2" value="Extra Bed Flamboyan AC (Limited Service): Rp 50.000">
                                <label class="custom-control-label" for="2">Extra Bed Flamboyan AC (Limited Service): Rp 50.000,-</label>
                            </div>
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" name="otherservice[]" class="custom-control-input" id="3" value="Extra Bed Flamboyan AC (full service): Rp 80.000">
                                <label class="custom-control-label" for="3">Extra Bed Flamboyan AC (full service): Rp 80.000,-</label>
                            </div>
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" name="otherservice[]" class="custom-control-input" id="4" value="Breakfast">
                                <label class="custom-control-label" for="4">Breakfast</label>
                            </div>
                        </div>
                    </div>
                    <button class="btn btn-primary" type="submit" name="konfirm">Konfirm</button>
                </form>
            </div>
        </div>
    </div>
    <hr>

 
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript">
        $(function(){
            $(".datepicker").datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true,
            });
        });
    </script>
</body>
</html>

