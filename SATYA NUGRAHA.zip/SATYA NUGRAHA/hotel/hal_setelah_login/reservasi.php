<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/png" href="../HSN/HSN_LOGO.png">
    <title>Hotel Satya Nugraha</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">


    <style>
        body{
            font-family:Arial;
            background-color:#F8F8FF;
            color:#000000;
        }
        .card-group{
            color:black;
        }
       
        
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark " >
        <img src="../HSN/HSN_LOGO.png" alt="">
        <a class="navbar-brand " href="#"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse " id="navbarTogglerDemo02">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0 " style="text-align:right;">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Home <span class="sr-only"></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">About us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Reservation</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="kontakhotel.php">Contact us</a>
                </li>
            </ul>
        </div>
        <div class="dropdown">
        <?php 
            session_start();  
            if($_SESSION['nama_user']=='')
            {
                header("location:../login.php");
            }      
        ?>
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo $_SESSION['nama_user']?>
        </button>
        
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
            <a class="dropdown-item" href="logout.php">Logout</a>
        </div>
        </div>
    </nav> <br>
        
    <div class="container">
        <div class="row justify-content-md-center">
            <div class="col-12 col-md-8">
                <h3 class="text-center">Type Rooms</h3><hr>
                <div class="card-group">
                    <div class="card">
                    <?php 
                    include '../koneksi.php';
                    $query = mysqli_query($connect, " SELECT gambar FROM kamar WHERE nomor_kamar IN ('104')");
                    while($row = mysqli_fetch_array($query)){
                    ?>
                        <img src="../../hotel_satyanugraha/images/<?php echo $row['gambar']?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Room Melati</h5>
                            <p class="card-text">We have a Melati Room with...</p>
                            <a href="roommelati.php" class="btn btn-primary">Read more</a>
                        </div>
                    <?php 
                        }
                    ?>
                    </div>
                    <div class="card">
                    <?php 
                    include '../koneksi.php';
                    $query = mysqli_query($connect, " SELECT gambar FROM kamar WHERE nomor_kamar IN ('103')");
                    while($row = mysqli_fetch_array($query)){
                    ?>
                        <img src="../../hotel_satyanugraha/images/<?php echo $row['gambar']?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Room Flamboyan</h5>
                            <p class="card-text">We have a Flamboyan Room with...</p>
                            <a href="roomflamboyan.php" class="btn btn-primary">Read More</a>
                        </div>
                    <?php 
                      }
                    ?>
                    </div>
                    <div class="card">
                    <?php 
                    include '../koneksi.php';
                    $query = mysqli_query($connect, " SELECT gambar FROM kamar WHERE nomor_kamar IN ('101')");
                    while($row = mysqli_fetch_array($query)){
                    ?>
                        <img src="../../hotel_satyanugraha/images/<?php echo $row['gambar']?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Room Anggrek</h5>
                            <p class="card-text">We have a special Anggrek Room with... </p>
                            <a href="roomanggrek.php" class="btn btn-primary">Read more</a>
                        </div> 
                    </div>
                    <?php 
                      }
                    ?>
                </div>
            </div>
        </div>
    </div>
    
        
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script type="text/javascript">
        $(function(){
            $(".datepicker").datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true,
            });
        });
    </script>
</body>
</html>