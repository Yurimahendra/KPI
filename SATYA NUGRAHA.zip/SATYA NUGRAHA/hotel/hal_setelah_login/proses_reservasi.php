<?php


$namatamu          = implode(" ", $_POST['namatamu']);
$noidentitas       = $_POST['noidentitas'];
$phone		       = $_POST['phone'];
$email             = $_POST['email'];
$checkin           = $_POST['checkin'];
$checkout          = $_POST['checkout'];
$pilihkamar        = $_POST['pilihkamar'];
$jumlahkamar       = $_POST['jumlahkamar'];
$otherservice      = implode(", ", $_POST['otherservice']);

include '../koneksi.php';

for ($i=0; $i<sizeof ($otherservice);$i++) {  
    $query = mysqli_query($connect, "INSERT INTO `reservation` (`id`, `nama_tamu`, `no_identitas`, `phone`, `email`, `check_in`, `check_out`, `pilih_kamar`, `jumlah_kamar`, `other_service` ) VALUES (NULL, '$namatamu', '$noidentitas', '$phone', '$email', '$checkin', '$checkout', '$pilihkamar', '$jumlahkamar', '".$otherservice."') " );
    
    }  

header("location:detaildata.php");

?> 