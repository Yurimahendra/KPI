<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/png" href="HSN/HSN_LOGO.png">
    <title>Hotel Satya Nugraha</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
        body{
            font-family:Arial;
            background-color:#F8F8FF;
            color:#000000;
        }
        #box:hover{
            background:#FFE4C4;
        }

        #box1:hover{
            background:#FFE4C4;
        }

        #box2:hover{
            background:#FFE4C4;
        }
        
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ">
        <img src="HSN/HSN_LOGO.png" alt="">
        <a class="navbar-brand " href="#"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse " id="navbarTogglerDemo02">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0 " style="text-align:right;">
                <li class="nav-item active">
                    <a class="nav-link" href="index.php">Home <span class="sr-only"></span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="index.php">About us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="reservasi.php">Reservation</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Contact us</a>
                </li>
            </ul>
        </div>
    </nav>
    <br>
    <div class="container">
        <center><h4>Contact Us</h4> </center>
        <hr>
        <div class="row justify-content-md-center">
            <div id="box" class="col-6 col-sm-4">
                &nbsp;
                <center>
                    <img src="HSN/address.png" width="50px" alt="">
                    <p>Jl. Sorowajan Baru No 16 Banguntapan Jogjakarta – Indonesia</p>
                </center>
            </div>
            <div id="box1" class="col-6 col-sm-4">
                &nbsp;
                <center>
                    <img src="HSN/fax.png" width="50px" alt="">
                    <p>Phone/Fax (+62-274) 484010 / (+62-274) 3154268</p>
                </center>
            </div>
            <div id="box2" class="col-6 col-sm-4">
                &nbsp;
                <center>
                    <img src="HSN/email.png" width="50px" alt="">
                    <p>Email <a href="https://www.google.com/gmail/">info@satyanugraha.com</a></p>
                </center>
            </div>
        </div><hr>
    </div>
        <center>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3953.0000806626017!2d110.39604671477808!3d-7.789814594386264!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a59e0734454d7%3A0xa863cbfc38e4c8bb!2sHotel+Satya+Nugraha+Syariah!5e0!3m2!1sid!2sid!4v1565064183349!5m2!1sid!2sid" width="600" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
        </center>
    
   
    
        
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>