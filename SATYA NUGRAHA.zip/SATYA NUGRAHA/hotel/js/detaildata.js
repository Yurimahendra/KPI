function tekan(){
    var namatamu     = (document.form.namatamu.value);
    var noidentitas  = (document.form.noidentitas.value);
    var email        = (document.form.email.value);
    var checkin      = (document.form.checkin.value);
    var checkout     = (document.form.checkout.value);
    var pilihkamar   = (document.form.pilihkamar.value);
    var jumlahkamar  = (document.form.jumlahkamar.value);
    var otherservice = (document.form.otherservice.value);

    document.output.onama.value = namatamu;
    document.output.onoid.value = noidentitas;
    document.output.oemail.value = email;
    document.output.ocheckin.value = checkin;
    document.output.ocheckout.value = checkout;
    document.output.opilihkamar.value = pilihkamar;
    document.output.ojumlahkamar.value = jumlahkamar;
    document.output.ootherservice.value = otherservice;



}