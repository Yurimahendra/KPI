<?php

date_default_timezone_set('Asia/Jakarta');

$url=$_SERVER['REQUEST_URI'];

?>