<?php
$host = "localhost";
$username = "root";
$password = "";
$db = "hotelsatya";
$mysqli = new mysqli($host,$username,$password, $db) or die('koneksi error');

?>