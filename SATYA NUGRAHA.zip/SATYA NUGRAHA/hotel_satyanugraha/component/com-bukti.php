<?php
include('config/config.php');



$buktibayar=$database->select('bukti_tf','*');

if(!empty($_GET['buktibayar'])) {

	$bukti_view=$database->get('bukti_tf','*',['id'=>$_GET['buktibayar']]);
}

if(isset($_POST['buktibayar-update'])) {

	$database->update('bukti_tf',[
		'nama_pemesan'=>$_POST['nama_pemesan'],
		'bukti_transfer'=>$_POST['bukti_transfer']
		],[
		'id'=>$_POST['id']
		]);
}

if(isset($_POST['buktibayar-del'])){

	$database->delete('bukti_tf',['id'=>$_POST['id']]);

	$alert='Anda telah berhasil melakukan penghapusan Bukti';

}
?>