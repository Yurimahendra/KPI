<?php
include('config/config.php');

$reservasi=$database->select('reservation','*');

if(!empty($_GET['reservation'])) {

	$reservasi_view=$database->get('reservation','*',['id'=>$_GET['reservation']]);
}

  ?>
