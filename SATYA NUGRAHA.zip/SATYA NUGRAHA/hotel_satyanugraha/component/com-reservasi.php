<?php


$reservasi=$database->select('reservation','*');

if(!empty($_GET['reservasi'])) {

	$reservasi_view=$database->get('reservation','*',['id'=>$_GET['reservasi']]);
}


//Update Reservasi

if(isset($_POST['reservasi-update'])) {

	$database->update('reservation',[
		'nama_tamu'=>$_POST['nama_tamu'],
		'no_identitas'=>$_POST['no_identitas'],
		'phone'=>$_POST['phone'],
		'email'=>$_POST['email'],
		'check_in'=>$_POST['check_in'],
		'check_out'=>$_POST['check_out'],
		'pilih_kamar'=>$_POST['pilih_kamar'],
		'jumlah_kamar'=>$_POST['jumlah_kamar'],
		'other_service'=>$_POST['other_service']
		],[
		'id'=>$_POST['id']
		]);
}

// Delete reservasi

if(isset($_POST['reservasi-del'])) {

	$database->delete('reservation',['id'=>$_POST['id']]);
}

?>

