-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 28 Agu 2019 pada 06.31
-- Versi server: 10.1.37-MariaDB
-- Versi PHP: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotelsatya`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bukti_bayar`
--

CREATE TABLE `bukti_bayar` (
  `id_bukti` int(3) NOT NULL,
  `nama-pemesan` varchar(100) NOT NULL,
  `gambar` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `bukti_tf`
--

CREATE TABLE `bukti_tf` (
  `id` int(11) NOT NULL,
  `nama-pemesan` varchar(30) NOT NULL,
  `bukti_transfer` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `bukti_tf`
--

INSERT INTO `bukti_tf` (`id`, `nama-pemesan`, `bukti_transfer`) VALUES
(7, 'aco yuri', 'membuat-telor-asin.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `finance_income`
--

CREATE TABLE `finance_income` (
  `id_finance_income` int(5) NOT NULL,
  `nomor_invoice` varchar(20) NOT NULL,
  `jenis_income` varchar(100) NOT NULL,
  `jumlah` int(20) NOT NULL,
  `tanggal_pembayaran` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kamar`
--

CREATE TABLE `kamar` (
  `id_kamar` int(3) NOT NULL,
  `nomor_kamar` int(3) NOT NULL,
  `id_kamar_tipe` int(3) NOT NULL,
  `max_dewasa` int(11) NOT NULL,
  `max_anak` int(11) NOT NULL,
  `gambar` varchar(100) NOT NULL,
  `status_kamar` varchar(20) NOT NULL DEFAULT 'TERSEDIA'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kamar`
--

INSERT INTO `kamar` (`id_kamar`, `nomor_kamar`, `id_kamar_tipe`, `max_dewasa`, `max_anak`, `gambar`, `status_kamar`) VALUES
(10, 101, 2, 2, 2, '22082019110351anggrek1.jpg', 'TERPAKAI'),
(14, 102, 3, 2, 2, '22082019111941anggrek2.jpg', 'TERPAKAI'),
(15, 103, 4, 2, 1, '22082019112014melati 1.jpg', 'TERPAKAI'),
(16, 104, 5, 2, 1, '22082019112048melati 2.jpg', 'TERSEDIA'),
(17, 105, 6, 2, 2, '2808201910452522082019112048melati 2.jpg', 'TERSEDIA'),
(18, 106, 7, 2, 2, '2808201910461222082019112014melati 1.jpg', 'TERSEDIA');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kamar_tipe`
--

CREATE TABLE `kamar_tipe` (
  `id_kamar_tipe` int(3) NOT NULL,
  `nama_kamar_tipe` varchar(50) NOT NULL,
  `harga_malam` int(3) NOT NULL,
  `harga_orang` int(3) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kamar_tipe`
--

INSERT INTO `kamar_tipe` (`id_kamar_tipe`, `nama_kamar_tipe`, `harga_malam`, `harga_orang`, `keterangan`) VALUES
(2, 'ANGGREK AC I', 340000, 0, '- AC\r\n- LCD TV\r\n- Hot Water\r\n- Bathub\r\n- Tea Set\r\n- Breakfast (Indonesian Food)\r\n- Sandal\r\n- Dental Kit\r\n- Handuk'),
(3, 'ANGGEK AC II', 280000, 0, '- AC\r\n- TV\r\n- Hot Water\r\n- Bathub\r\n- Tea Set\r\n- Breakfast (Indonesian Food)\r\n- Sandal\r\n- Dental Kit\r\n- Handuk'),
(4, 'MELATI AC I', 250000, 0, '- AC\r\n- LED TV\r\n- Hot Water\r\n- Shower\r\n- Tea Set\r\n- Breakfast\r\n- Sandal\r\n- Handuk '),
(5, 'MELATI AC II', 200000, 0, '- AC\r\n- LED TV\r\n- Shower\r\n- Tea Set\r\n- breakfast\r\n- Sandal\r\n- Handuk'),
(6, 'FLAMBOYAN AC (Limited Service)', 130000, 0, '- AC\r\n- TV'),
(7, 'FLAMBOYAN AC', 190000, 0, '-Full Service');

-- --------------------------------------------------------

--
-- Struktur dari tabel `layanan`
--

CREATE TABLE `layanan` (
  `id_layanan` int(3) NOT NULL,
  `nama_layanan` varchar(100) NOT NULL,
  `id_layanan_kategori` int(3) NOT NULL,
  `satuan` varchar(30) NOT NULL,
  `harga_layanan` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `layanan`
--

INSERT INTO `layanan` (`id_layanan`, `nama_layanan`, `id_layanan_kategori`, `satuan`, `harga_layanan`) VALUES
(1, 'NASI GORENG', 1, 'Porsi', 25000),
(2, 'MIE GORENG', 1, 'Porsi', 15000),
(3, 'KOPI TUBRUK', 2, 'Pitcher', 85000),
(4, 'HEM', 4, '1', 10000),
(5, 'Extra Bed Anggrek AC I/II', 5, ' 1', 118000),
(6, 'Extra Bed Melati AC I/II', 5, '1', 98000),
(7, 'Extra Bed Flamboyan AC (Limited Service)', 5, '1', 50000),
(8, 'Extra Bed Flamboyan AC (full service)', 5, '1', 80000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `layanan_kategori`
--

CREATE TABLE `layanan_kategori` (
  `id_layanan_kategori` int(3) NOT NULL,
  `nama_layanan_kategori` varchar(100) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `layanan_kategori`
--

INSERT INTO `layanan_kategori` (`id_layanan_kategori`, `nama_layanan_kategori`, `keterangan`) VALUES
(1, 'FOOD', 'Produk makanan, snack, sarapan dan lain-lain'),
(2, 'DRINK', 'Produk minuman'),
(3, 'TRANSPORTASI', 'Fasilitas transportasi untuk kebutuhan tamu hotel'),
(4, 'LAUNDRY', 'LAUNDRY'),
(5, 'Other Services', 'Layanan Kamar\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perusahaan`
--

CREATE TABLE `perusahaan` (
  `id_perusahaan` int(100) NOT NULL,
  `nama_hotel` varchar(100) NOT NULL,
  `nama_perusahaan` varchar(100) NOT NULL,
  `alamat_jalan` text NOT NULL,
  `alamat_kabupaten` varchar(50) NOT NULL,
  `alamat_provinsi` varchar(50) NOT NULL,
  `nomor_telp` varchar(20) NOT NULL,
  `nomor_fax` varchar(20) NOT NULL,
  `website` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `perusahaan`
--

INSERT INTO `perusahaan` (`id_perusahaan`, `nama_hotel`, `nama_perusahaan`, `alamat_jalan`, `alamat_kabupaten`, `alamat_provinsi`, `nomor_telp`, `nomor_fax`, `website`, `email`) VALUES
(1, 'SATYA NUGRAHA', 'HOTEL', 'Jl. Sorowajan Baru No 16 Banguntapan Jogjakarta – Indonesia', 'Yogyakarta', 'Jawa Tengah', ' (+62-274) 484010', ' (+62-274) 3154268', 'http://www.satyanugraha.com', ' info@satyanugraha.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `register`
--

CREATE TABLE `register` (
  `id` int(11) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `register`
--

INSERT INTO `register` (`id`, `email`, `username`, `password`) VALUES
(1, 'yurimahendra40@gmail.com', 'yuri', '1428beff6a839f01158d91d7d3874484'),
(2, 'frank@gmail.com', 'castle', '597b98a2dc7785ccca8409570c689163'),
(3, 'frank@gmail.com', 'castle', '597b98a2dc7785ccca8409570c689163'),
(4, 'admin@gmail.com', 'admin', 'c3284d0f94606de1fd2af172aba15bf3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `reservasi`
--

CREATE TABLE `reservasi` (
  `id_reservasi` int(3) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nomor_identitas` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `chek_in` date NOT NULL,
  `chek_out` date NOT NULL,
  `nama_kamar` varchar(100) NOT NULL,
  `jumlah_kamar` int(20) NOT NULL,
  `other_sevice` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `reservasi`
--

INSERT INTO `reservasi` (`id_reservasi`, `nama`, `nomor_identitas`, `phone`, `email`, `chek_in`, `chek_out`, `nama_kamar`, `jumlah_kamar`, `other_sevice`) VALUES
(1, 'qw', 'qq', '1', 'qq', '2019-08-21', '2019-08-22', 'qwww', 1, 'qwqqe');

-- --------------------------------------------------------

--
-- Struktur dari tabel `reservation`
--

CREATE TABLE `reservation` (
  `id` int(11) NOT NULL,
  `nama_tamu` varchar(30) DEFAULT NULL,
  `no_identitas` int(11) DEFAULT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `check_in` date DEFAULT NULL,
  `check_out` date DEFAULT NULL,
  `pilih_kamar` varchar(25) DEFAULT NULL,
  `jumlah_kamar` int(11) DEFAULT NULL,
  `other_service` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `reservation`
--

INSERT INTO `reservation` (`id`, `nama_tamu`, `no_identitas`, `phone`, `email`, `check_in`, `check_out`, `pilih_kamar`, `jumlah_kamar`, `other_service`) VALUES
(23, 'Yuri Mahendra', 26, '', 'yurimahendra40@gmail.com', '2019-08-22', '2019-08-23', 'ANGGREK AC I Rp 340.000', 1, 'Extra Bed Anggrek AC I/II: Rp 118.000, Breakfast'),
(24, 'Frank', 7, '12345678', 'frank@gmail.com', '2019-08-22', '2019-08-23', 'ANGGREK AC I Rp 340.000', 1, 'Breakfast'),
(25, 'Frank', 7, '', 'frank@gmail.com', '2019-08-22', '2019-08-23', 'ANGGREK AC I Rp 340.000', 1, 'Breakfast'),
(26, 'Yuri Mahendra', 9900, '', 'yurimahendra40@gmail.com', '2019-08-23', '2019-08-24', 'ANGGREK AC I Rp 340.000', 1, 'Breakfast'),
(27, 'aco', 575, '', 'aco@gmail.com', '2019-08-23', '2019-08-24', 'ANGGREK AC I Rp 340.000', 1, 'Extra Bed Anggrek AC I/II: Rp 118.000, Breakfast'),
(28, 'yuri mahendra', 564556, '65465456', 'yuri@gmail.com', '2019-08-27', '2019-08-28', 'ANGGREK AC I Rp 340.000', 1, 'Breakfast');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tamu`
--

CREATE TABLE `tamu` (
  `id_tamu` int(3) NOT NULL,
  `prefix` varchar(5) NOT NULL,
  `nama_depan` varchar(100) NOT NULL,
  `nama_belakang` varchar(100) NOT NULL,
  `tipe_identitas` varchar(20) NOT NULL,
  `nomor_identitas` varchar(20) NOT NULL,
  `warga_negara` varchar(100) NOT NULL DEFAULT 'Indonesia',
  `alamat_jalan` text NOT NULL,
  `alamat_kabupaten` varchar(100) NOT NULL,
  `alamat_provinsi` varchar(100) NOT NULL,
  `nomor_telp` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tamu`
--

INSERT INTO `tamu` (`id_tamu`, `prefix`, `nama_depan`, `nama_belakang`, `tipe_identitas`, `nomor_identitas`, `warga_negara`, `alamat_jalan`, `alamat_kabupaten`, `alamat_provinsi`, `nomor_telp`, `email`) VALUES
(4, 'Mr', 'Bagus', 'Prasetya', 'KTP', '5121827187291892', 'WNI', 'Jalan Slamet Riyadi 92', 'Pasuruan', 'Jawa Timur', '085655580445', 'bagusprasetya96@gmail.com'),
(5, 'Mr', 'deni', 'devito', 'KTP', '123213213213213', 'WNI', 'jl kakap', 'bandung', 'jabar', '213213554635464', 'deni@yashoo.com'),
(6, 'Mr', 'aco', 'nasroh', 'KTP', '12345', 'wni', 'tegal', 'tegal', 'Jawa Tengah', '0987654', 'ae@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_kamar`
--

CREATE TABLE `transaksi_kamar` (
  `id_transaksi_kamar` int(3) NOT NULL,
  `id_user` int(3) NOT NULL,
  `nomor_invoice` varchar(20) NOT NULL,
  `tanggal` date NOT NULL,
  `id_tamu` int(3) NOT NULL,
  `id_kamar` int(3) NOT NULL,
  `jumlah_dewasa` int(3) NOT NULL,
  `jumlah_anak` int(3) NOT NULL,
  `tanggal_checkin` date NOT NULL,
  `waktu_checkin` time NOT NULL,
  `tanggal_checkout` date NOT NULL,
  `waktu_checkout` time NOT NULL,
  `total_biaya_kamar` int(20) NOT NULL,
  `deposit` int(20) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'CHECK IN'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `transaksi_kamar`
--

INSERT INTO `transaksi_kamar` (`id_transaksi_kamar`, `id_user`, `nomor_invoice`, `tanggal`, `id_tamu`, `id_kamar`, `jumlah_dewasa`, `jumlah_anak`, `tanggal_checkin`, `waktu_checkin`, `tanggal_checkout`, `waktu_checkout`, `total_biaya_kamar`, `deposit`, `status`) VALUES
(20, 1, 'INV-20180815-26', '2018-08-15', 4, 7, 1, 1, '2018-08-15', '16:56:00', '2018-07-31', '12:00:00', 1500000, 500000, 'CHECK OUT'),
(21, 1, 'INV-20180815-25', '2018-08-15', 4, 1, 2, 2, '2018-08-15', '16:57:00', '2018-07-31', '12:00:00', 1500000, 500000, 'CHECK OUT'),
(22, 1, 'INV-20180815-90', '2018-08-15', 0, 6, 2, 1, '2018-08-15', '17:31:00', '2018-08-15', '18:00:00', 0, 1500000, 'CHECK IN'),
(23, 4, 'INV-20180815-20', '2018-08-15', 5, 1, 2, 1, '2018-08-15', '20:28:00', '2018-08-16', '12:00:00', 100000, 300000, 'CHECK OUT'),
(24, 1, 'INV-20180815-21', '2018-08-15', 5, 1, 2, 1, '2018-08-15', '20:58:00', '2018-08-16', '12:00:00', 100000, 1000000, 'CHECK OUT'),
(25, 1, 'INV-20190814-63', '2019-08-14', 4, 1, 2, 2, '2019-08-14', '15:28:00', '2019-08-15', '12:00:00', 100000, 12000000, 'CHECK OUT'),
(26, 1, 'INV-20190815-81', '2019-08-15', 0, 7, 2, 1, '2019-08-15', '17:54:00', '2019-08-21', '12:00:00', 2040000, 12000000, 'CHECK IN'),
(27, 1, 'INV-20190815-81', '2019-08-15', 0, 7, 2, 1, '2019-08-15', '17:54:00', '2019-08-21', '12:00:00', 2040000, 12000000, 'CHECK IN'),
(28, 1, 'INV-20190822-66', '2019-08-22', 0, 14, 1, 2, '2019-08-22', '11:48:00', '2019-08-23', '12:00:00', 280000, 300000, 'CHECK IN'),
(29, 1, 'INV-20190828-27', '2019-08-28', 6, 15, 1, 0, '2019-08-28', '10:48:00', '2019-08-29', '12:00:00', 250000, 500000, 'CHECK IN');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi_layanan`
--

CREATE TABLE `transaksi_layanan` (
  `id_transaksi_layanan` int(3) NOT NULL,
  `id_user` int(3) NOT NULL,
  `tanggal` date NOT NULL,
  `waktu` time NOT NULL,
  `id_transaksi_kamar` int(3) NOT NULL,
  `id_layanan` int(3) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `transaksi_layanan`
--

INSERT INTO `transaksi_layanan` (`id_transaksi_layanan`, `id_user`, `tanggal`, `waktu`, `id_transaksi_kamar`, `id_layanan`, `jumlah`, `total`) VALUES
(30, 1, '2018-08-15', '18:24:00', 20, 3, 1, 85000),
(31, 1, '2018-08-15', '18:24:00', 20, 2, 2, 30000),
(32, 1, '2018-08-15', '18:24:00', 20, 1, 1, 25000),
(33, 1, '2018-08-15', '20:59:00', 24, 4, 5, 50000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(3) NOT NULL,
  `images` varchar(100) NOT NULL DEFAULT 'user.jpg',
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `id_user_role` int(5) NOT NULL,
  `jabatan` varchar(100) NOT NULL,
  `nomor_telp` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `images`, `username`, `password`, `nama`, `id_user_role`, `jabatan`, `nomor_telp`) VALUES
(1, 'default.jpg', 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Nama Administrator', 1, 'Application Developer', '0800 0000 0000'),
(4, 'default.jpg', 'iteung', 'e92ab3bc72b384a3b1e0f7eaee90a863', 'iteung', 4, 'FO', '081565465465465'),
(5, 'default.jpg', 'manager', '1d0258c2440a8d19e716292b231e3190', 'manager', 2, 'Manager', ' (+62-274) 484010'),
(6, 'user.jpg', 'yuri', '9491876179d7a80bb5c86f15dbe31422', 'yuri', 3, 'admin', '123432'),
(7, 'user.jpg', 'dev', 'e77989ed21758e78331b20e477fc5582', 'Lahan 1', 1, 'developer', '123456789');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE `user_role` (
  `id_user_role` int(10) NOT NULL,
  `role_name` varchar(100) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`id_user_role`, `role_name`, `keterangan`) VALUES
(1, 'DEVELOPER', 'Akses khusus untuk pembuat aplikasi'),
(2, 'SUPER ADMINISTRATOR', ''),
(3, 'ADMINISTRATOR', ''),
(4, 'FRONT OFFICE', ''),
(5, 'ROOM SERVICE', '');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bukti_bayar`
--
ALTER TABLE `bukti_bayar`
  ADD PRIMARY KEY (`id_bukti`);

--
-- Indeks untuk tabel `bukti_tf`
--
ALTER TABLE `bukti_tf`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `finance_income`
--
ALTER TABLE `finance_income`
  ADD PRIMARY KEY (`id_finance_income`);

--
-- Indeks untuk tabel `kamar`
--
ALTER TABLE `kamar`
  ADD PRIMARY KEY (`id_kamar`);

--
-- Indeks untuk tabel `kamar_tipe`
--
ALTER TABLE `kamar_tipe`
  ADD PRIMARY KEY (`id_kamar_tipe`);

--
-- Indeks untuk tabel `layanan`
--
ALTER TABLE `layanan`
  ADD PRIMARY KEY (`id_layanan`);

--
-- Indeks untuk tabel `layanan_kategori`
--
ALTER TABLE `layanan_kategori`
  ADD PRIMARY KEY (`id_layanan_kategori`);

--
-- Indeks untuk tabel `perusahaan`
--
ALTER TABLE `perusahaan`
  ADD PRIMARY KEY (`id_perusahaan`);

--
-- Indeks untuk tabel `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `reservasi`
--
ALTER TABLE `reservasi`
  ADD PRIMARY KEY (`id_reservasi`);

--
-- Indeks untuk tabel `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tamu`
--
ALTER TABLE `tamu`
  ADD PRIMARY KEY (`id_tamu`);

--
-- Indeks untuk tabel `transaksi_kamar`
--
ALTER TABLE `transaksi_kamar`
  ADD PRIMARY KEY (`id_transaksi_kamar`);

--
-- Indeks untuk tabel `transaksi_layanan`
--
ALTER TABLE `transaksi_layanan`
  ADD PRIMARY KEY (`id_transaksi_layanan`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- Indeks untuk tabel `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id_user_role`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `bukti_tf`
--
ALTER TABLE `bukti_tf`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `finance_income`
--
ALTER TABLE `finance_income`
  MODIFY `id_finance_income` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `kamar`
--
ALTER TABLE `kamar`
  MODIFY `id_kamar` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `kamar_tipe`
--
ALTER TABLE `kamar_tipe`
  MODIFY `id_kamar_tipe` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `layanan`
--
ALTER TABLE `layanan`
  MODIFY `id_layanan` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `layanan_kategori`
--
ALTER TABLE `layanan_kategori`
  MODIFY `id_layanan_kategori` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `perusahaan`
--
ALTER TABLE `perusahaan`
  MODIFY `id_perusahaan` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `register`
--
ALTER TABLE `register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `reservation`
--
ALTER TABLE `reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT untuk tabel `tamu`
--
ALTER TABLE `tamu`
  MODIFY `id_tamu` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `transaksi_kamar`
--
ALTER TABLE `transaksi_kamar`
  MODIFY `id_transaksi_kamar` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT untuk tabel `transaksi_layanan`
--
ALTER TABLE `transaksi_layanan`
  MODIFY `id_transaksi_layanan` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id_user_role` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
