<?php

include('component/com-register.php');

?>

<section class="content-header">
	<h1>Registrasi <span class="small">Administrasi tamu hotel</span></h1>
</section>

<section class="content">
	<div class="box">
		
		<div class="box-body">
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>Id </th>
						<th>Email</th>
                        <th>Username </th>
                         <th>Password</th>
					</tr>
				</thead>
				<tbody>
					<?php
                     $query = $mysqli->query("SELECT * FROM register");
                     $id=1;
                     while ($lihat=mysqli_fetch_array($query)){
                      ?>
					<tr>
						<td><?php echo $id++; ?></td>
                        <td><?php echo $lihat['email']; ?></td>
                        <td><?php echo $lihat['username']; ?></td>
                        <td><?php echo $lihat['password']; ?></td>
                        

					</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</section>