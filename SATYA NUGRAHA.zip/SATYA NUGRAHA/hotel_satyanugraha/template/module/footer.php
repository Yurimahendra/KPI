<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 7.2.12  PHP
        </div>
        <strong>Copyright &copy; 2019 <a href="#">CV. Satya Nugraha</a>.</strong> All rights reserved.
      </footer>