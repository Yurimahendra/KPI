<?php

include('component/com-bukti.php');

?>

<section class="content-header">
	<h1>Bukti Bayar <span class="small">Administrasi tamu hotel</span></h1>
</section>

<section class="content">
	<div class="box">
		
		<div class="box-body">
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>Id Bukti</th>
						<th>Nama Pemesan</th>
                        <th>Bukti Transfer </th>
                         <th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($buktibayar as $bukti)  { ?>
					<tr>
						<td><?php echo $bukti['id']; ?></td>
                        <td><?php echo $bukti['nama-pemesan']; ?></td>
                        <td>
                              <img src="images/<?php echo $bukti['bukti_transfer'];?>" width="200" height='100'>
                            </td>
                         
						<td>
							<a class="btn btn-danger btn-info"  href="?module=buktibayar/bukti-delete&buktibayar=<?php echo $bukti['id']; ?>">Hapus</a>
							
							
						</td>

					</tr>
					<?php } ?>
				</tbody>
			</table>
		</div>
	</div>
</section>