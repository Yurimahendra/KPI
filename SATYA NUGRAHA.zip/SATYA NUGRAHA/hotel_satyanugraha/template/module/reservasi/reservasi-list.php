<?php

include('component/com-reservasi.php');

?>

<section class="content-header">
	<h1>Reservasi <span class="small">Administrasi tamu hotel</span></h1>
</section>

<section class="content">
	<div class="box">
		<div class="box-body">
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						  <th>Id</th>
                          <th>Nama Tamu</th>
                          <th>No identitas </th>
                          <th>Phone</th>
                          <th>Email</th>
                          <th>Check In</th>
                          <th>Check Out</th>
                          <th>Nama Kamar</th>
                          <th>Jumlah Kamar</th>
                          <th>Other Service</th>
                          <th>Opsi</th>
					</tr>
				</thead>
				<tbody>
                      <?php foreach ($reservasi as $reservasi)  { ?>
					<tr>
						<td><?php echo number_format ($reservasi['id']); ?></td>
                        <td><?php echo $reservasi['nama_tamu']; ?></td>
                        <td><?php echo $reservasi['no_identitas'];?></td>
                        <td><?php echo $reservasi['phone']; ?></td>
                        <td><?php echo $reservasi['email']; ?></td>
                        <td><?php echo $reservasi['check_in'];  ?></td>
                        <td><?php echo $reservasi['check_out'];  ?></td>
                        <td><?php echo $reservasi['pilih_kamar'];  ?></td>
                        <td><?php echo $reservasi['jumlah_kamar'];  ?></td>
                        <td><?php echo $reservasi['other_service'];  ?></td>
						<td>
							<a class="btn btn-xs btn-info" href="?module=reservasi/reservasi-update&reservasi=<?php echo number_format($reservasi['id']); ?>">Update</a>
							
					</tr>
					<?php  } ?>
					
				</tbody>
			</table>
		</div>
	</div>
</section>