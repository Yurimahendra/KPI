<?php
include('component/com-reservasi.php')
//include('component/com-reservasi.php');

?>

<section class="content-header">
	<h1>UPDATE RESERVASI</h1>
</section>

<section class="content">
	<?php if(isset($_POST['reservasi-update'])) { ?>
	<div class="alert alert-success">
		<h4>Berhasil</h4>
		Anda telah berhasil melakukan perubahan data reservasi. 
		<a href="?module=reservasi/reservasi-list"><b>Kembali</b></a>
	</div>
	<?php } else { ?>
	<div class="box">		
		<form action="" method="post">			
			<div class="box-body">
				<div class="row">
					<div class="col-sm-4">
						<div class="form-group">
							<label>Nama Tamu</label>
							<input type="text" class="form-control" name="nama_tamu" value="<?php echo $reservasi_view['nama_tamu']; ?>"/>
						</div>
						<div class="form-group">
							<label>Nomor_Identitas</label>
							<input class="form-control" name="no_identitas" value="<?php echo $reservasi_view['no_identitas']; ?>" />
						</div>
						<div class="form-group">
							<label>Phone</label>
							<input class="form-control" name="phone" value="<?php echo $reservasi_view['phone']; ?>" />
						</div>
						<div class="form-group">
							<label>Email</label>
							<input class="form-control" name="email" value="<?php echo  $reservasi_view['email']; ?>" />
						</div>
						<div class="form-group">
							<label>Check-In</label>
							<input type="date" class="form-control" name="check_in" value="<?php echo  $reservasi_view['check_in']; ?>" />
						</div>
						<div class="form-group">
							<label>Check-Out</label>
							<input type="date" class="form-control" name="check_out" value="<?php echo $reservasi_view['check_out']; ?>" />
						</div>
						<div class="form-group">
							<label>Pilih Kamar</label>
							<input class="form-control" name="pilih_kamar" value="<?php echo $reservasi_view['pilih_kamar']; ?>" />
						</div>
						<div class="form-group">
							<label>Jumlah_Kamar</label>
							<input class="form-control" name="jumlah_kamar" value="<?php echo $reservasi_view['jumlah_kamar']; ?>" />
						</div>
						<div class="form-group">
							<label>Other Service</label>
							<input type="text" class="form-control" name="other_service" value="<?php echo $reservasi_view['other_service']; ?>" />
						</div>
					</div>
				</div>
				</div>
			</div>
			<div class="box-footer">
				<input type="hidden" name="id" value="<?php echo  $reservasi_view['id']; ?>" />
				<button class="btn btn-success" type="submit" name="reservasi-update">Update Reservasi</button>
				<a class="btn btn-danger" href="?module=reservasi/reservasi-delete&reservasi=<?php echo  $reservasi_view['id']; ?>">Hapus</a>
				<a class="btn btn-warning" href="?module=reservasi/reservasi-list">Batal</a>
			</div>
		</form>
		
	</div>
	<?php } ?>
</section>
