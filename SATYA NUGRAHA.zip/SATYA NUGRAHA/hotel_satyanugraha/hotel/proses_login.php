<?php 

    $username      = $_POST['name'];
    $pass          = MD5($_POST['pass']);

    include 'koneksi.php';

    $user = mysqli_query($connect, "SELECT * FROM register WHERE username= '$username' AND password = MD5('$pass')");
    $chek = mysqli_fetch_assoc($user);
      
    if($chek > 0)
    {
        header("location:form_reservasi.php");
        exit;
    }else
    {
        
        header("location:login.php");
    }
?>