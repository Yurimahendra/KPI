<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Bukti Transfer</title>
</head>
<body>
    <?php 
    include 'koneksi.php';
    if($_POST['upload']){
        $ekstensi_diperbolehkan	= array('png','jpg');
        $nama = $_FILES['file']['name'];
        $x = explode('.', $nama);
        $ekstensi = strtolower(end($x));
        $ukuran	= $_FILES['file']['size'];
        $file_tmp = $_FILES['file']['tmp_name'];	
            if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
                if($ukuran < 1044070){			
                move_uploaded_file($file_tmp, '../images/'.$nama);
                $query = mysqli_query($connect, "INSERT INTO `bukti_tf` (`id`, `bukti_transfer`) VALUES (NULL, '$nama')");
                if($query){
                    echo 'FILE BERHASIL DI UPLOAD';
                }else{
                    echo 'GAGAL MENGUPLOAD GAMBAR';
                }
                }else{
                echo 'UKURAN FILE TERLALU BESAR';
                }
            }else{
            echo 'EKSTENSI FILE YANG DI UPLOAD TIDAK DI PERBOLEHKAN';
            }
        }
    ?>

        <table>
            <?php 
            include 'koneksi.php';
			$data = mysqli_query($connect, "SELECT * FROM `bukti_tf` WHERE id IN (SELECT MAX(id) FROM `bukti_tf`)");
			while($d = mysqli_fetch_array($data)){
			?>
			<tr>
				<td>
					<img src="<?php echo "../images/".$d['bukti_transfer']; ?>">
				</td>		
			</tr>
			<?php } ?>
		</table>

</body>
</html>