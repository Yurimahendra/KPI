<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/png" href="HSN/HSN_LOGO.png">
    <title>Hotel Satya Nugraha</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css">


    <style>

        body{
            font-family:Arial;
            background-color:#F8F8FF;
            color:#000000;
        }
        
        .card{
            color: black;
            text-align: left;
        }

        #detail{
            text-align: left;
        }
        
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ">
        <img src="HSN/HSN_LOGO.png" alt="">
        <a class="navbar-brand " href="#"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse " id="navbarTogglerDemo02">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0 " >
                <li class="nav-item active ">
                    <a class="nav-link" href="index.php">Home <span class="sr-only"></span></a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="index.php">About us</a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="reservasi.php">Reservation</a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="kontakhotel.php">Contact us</a>
                </li>
            </ul>
        </div>
    </nav> <br>
        
    <div class="container">
        <div class="row justify-content-md-center">
            <div class="col-lg-auto">
                <h3 class="text-center">Detail Data</h3>
                <?php 
                    include 'koneksi.php';
                    $query = mysqli_query($connect, "SELECT * FROM reservation WHERE id IN (SELECT MAX(id) FROM reservation)");
                    while ($hasil=mysqli_fetch_array($query)) {   
                            
                ?>
                <center>
                        <div class="card" style="width: 30rem;">
                            <div class="card-group">
                                <small id="emailHelp" class="form-text col-sm-4 ">Name Guest </small>:&nbsp;
                                <small id="emailHelp" class="form-text " name="onama"><?= $hasil['nama_tamu']?></small>
                                
                            </div>
                            <div class="card-group">
                                <small id="emailHelp" class="form-text col-sm-4 ">No. KTP/Pasport/SIM</small>:&nbsp;
                                <small id="emailHelp" class="form-text " name="onoid"> <?= $hasil['no_identitas']?></small>
                            </div>
                            <div class="card-group">
                                <small id="emailHelp" class="form-text col-sm-4 ">Email </small>:&nbsp;
                                <small id="emailHelp" class="form-text" name="oemail"><?= $hasil['email']?></small>
                            </div>
                            <div class="card-group">
                                <small id="emailHelp" class="form-text col-sm-4 ">Check In </small>:&nbsp;
                                <small id="emailHelp" class="form-text " name="ocheckin"><?= $hasil['check_in']?> </small>
                            </div>
                            <div class="card-group">
                                <small id="emailHelp" class="form-text col-sm-4 ">Check Out </small>:&nbsp;
                                <small id="emailHelp" class="form-text" name="ocheckout"><?= $hasil['check_out']?> </small>
                            </div>
                            <div class="card-group">
                                <small id="emailHelp" class="form-text col-sm-4 ">Pilih Kamar </small>:&nbsp;
                                <small id="emailHelp" class="form-text " name="opilihkamar"> <?= $hasil['pilih_kamar']?></small>
                            </div>
                            <div class="card-group">
                                <small id="emailHelp" class="form-text col-sm-4 ">Jumlah Kamar </small>:&nbsp;
                                <small id="emailHelp" class="form-text " name="ojumlahkamar"><?= $hasil['jumlah_kamar']?></small>
                            </div>
                            <div class="card-group">
                                <small id="emailHelp" class="form-text col-sm-4 ">Other Service</small>:&nbsp;
                                <small id="emailHelp" class="form-text " name="ootherservice"><?= $hasil['other_service']?></small>
                            </div>
                        </div>
                        <br>
                        <?php } ?>
                        
                        <?php 
                        $anggrek = "ANGGREK AC I Rp 340.000";
                        $anggrek1 = "ANGGREK AC II Rp 280.000";
                        $melati = "MELATI AC I Rp 250.000";
                        $melati1 = "MELATI AC II Rp 200.000";
                        $flamboyan = "FLAMBOYAN AC Rp 130.000";
                        $flamboyan1 = "FLAMBOYAN AC Rp 190.000";

                        $service = "Extra Bed Anggrek AC I/II: Rp 118.000";
                        $service1 = "Extra Bed Melati AC I/II: Rp 98.000";
                        $service2 = "Extra Bed Flamboyan AC (Limited Service): Rp 50.000";
                        $service3 = "Extra Bed Flamboyan AC (full service): Rp 80.000";
                        $service4 = "Breakfast";

                        $data = $_POST['opilihkamar'];
                        $data1 = $_POST['ootherservice'];

                        if($data == $anggrek):
                            echo 340000;
                        elseif($data == $anggrek1):
                            echo 280000;
                        elseif($data == $melati):
                            echo 250000;
                        elseif($data == $melati1):
                            echo 200000;
                        elseif($data == $flamboyan):
                            echo 130000;
                        elseif($data == $flamboyan1):
                            echo 190000;
                        return $data;
                        endif;

                        if($data1 == $service):
                            echo 118000;
                        elseif($data1 == $service1):
                            echo 98000;
                        elseif($data1 == $service2):
                            echo 50000;
                        elseif($data1 == $service3):
                            echo 80000;
                        elseif($data1 == $service4):
                            echo 25000;
                        return $data1;
                        endif;

                        $total = $data + $data1;
                    ?>
                    
                <form action="proses_upload.php" method="post" enctype="multipart/form-data" id="detail">
                
                    <div class="form-group row">
                        <label for="staticTotal" class="col-sm-5 col-form-label">Total Bayar</label>
                        <div class="col">
                            <input type="text" readonly class="form-control-plaintext" id="staticTotal" value=<?= $data?>>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="staticTotal" class="col-sm-5 col-form-label">Metode Pembayaran</label>
                        <div class="col-sm-4">
                        <select class="custom-select" id="" required>
                                <option value="1">Tunai</option>
                                <option value="2">Transfer</option>
                        </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="staticTotal" class="col-sm-5 col-form-label">Waktu Pembayaran</label>
                        <div class="col">
                            <input  type="text" readonly class="form-control-plaintext" id="staticTotal" value="1x24 jam">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="buktipembayaran" class="col-sm-5 col-form-label">Bukti Pembayaran</label>
                        <div class="col">
                            <input type="file" name="file" class="form-control-file" id="buktipembayaran"><br>
                            <input type="submit" name="upload" value="Upload"/>
                        </div>
                    </div>
                </form>
                </center>
            </div>
        </div>
    </div>
    <hr>
    
    <script type="text/javascript" src="js/detaildata.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    
</body>
</html>