<?php
$host       = "localhost";
$user       = "root";
$password   = "";
$database   = "hotelnew";
$connect    = mysqli_connect($host, $user, $password, $database);

if (!$connect){
    die("koneksi error !" . mysqli_connect_error());
}
?>